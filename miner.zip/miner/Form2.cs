﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace miner
{
    public partial class Form2 : Form
    {
        private Random rnd = new Random();
        private System.Drawing.Image[] images = new System.Drawing.Image[2];
        private Button[] buttons = new Button[25];
        private List<int> bombIndexes = new List<int>(); 
        public Form2()
        {
            InitializeComponent();
        }

        private int countClicks = 0;
        private int bombsCount;
        public int BombsCount 
        {
            get { return bombsCount; }
            set { bombsCount = value; }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            ImagesLoad();
            InitButtons();
            BombLoad();
            label1.Text = $"Бомб: {BombsCount}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Button button1 = (Button)sender;

            if (button1.Tag == "Bomb")
            {
                button1.Image = images[1];
                button1.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button1.Image = images[0];
                button1.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button1.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Button button2 = (Button)sender;

            if (button2.Tag == "Bomb")
            {
                button2.Image = images[1];
                button2.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button2.Image = images[0];
                button2.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button2.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Button button3 = (Button)sender;

            if (button3.Tag == "Bomb")
            {
                button3.Image = images[1];
                button3.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button3.Image = images[0];
                button3.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button3.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Button button4 = (Button)sender;

            if (button4.Tag == "Bomb")
            {
                button4.Image = images[1];
                button4.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button4.Image = images[0];
                button4.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button4.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button button5 = (Button)sender;

            if (button5.Tag == "Bomb")
            {
                button5.Image = images[1];
                button5.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button5.Image = images[0];
                button5.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button5.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Button button6 = (Button)sender;

            if (button6.Tag == "Bomb")
            {
                button6.Image = images[1];
                button6.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button6.Image = images[0];
                button6.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button6.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Button button7 = (Button)sender;

            if (button7.Tag == "Bomb")
            {
                button7.Image = images[1];
                button7.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button7.Image = images[0];
                button7.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button7.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Button button8 = (Button)sender;

            if (button8.Tag == "Bomb")
            {
                button8.Image = images[1];
                button8.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button8.Image = images[0];
                button8.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button8.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Button button9 = (Button)sender;

            if (button9.Tag == "Bomb")
            {
                button9.Image = images[1];
                button9.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button9.Image = images[0];
                button9.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button9.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Button button10 = (Button)sender;

            if (button10.Tag == "Bomb")
            {
                button10.Image = images[1];
                button10.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button10.Image = images[0];
                button10.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button10.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Button button11 = (Button)sender;

            if (button11.Tag == "Bomb")
            {
                button11.Image = images[1];
                button11.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button11.Image = images[0];
                button11.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button11.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Button button12 = (Button)sender;

            if (button12.Tag == "Bomb")
            {
                button12.Image = images[1];
                button12.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button12.Image = images[0];
                button12.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button12.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                   // Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Button button13 = (Button)sender;

            if (button13.Tag == "Bomb")
            {
                button13.Image = images[1];
                button13.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button13.Image = images[0];
                button13.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button13.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Button button14 = (Button)sender;

            if (button14.Tag == "Bomb")
            {
                button14.Image = images[1];
                button14.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button14.Image = images[0];
                button14.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button14.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Button button15 = (Button)sender;

            if (button15.Tag == "Bomb")
            {
                button15.Image = images[1];
                button15.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button15.Image = images[0];
                button15.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button15.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Button button16 = (Button)sender;

            if (button16.Tag == "Bomb")
            {
                button16.Image = images[1];
                button16.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button16.Image = images[0];
                button16.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button16.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }

        }

        private void button17_Click(object sender, EventArgs e)
        {
            Button button17 = (Button)sender;

            if (button17.Tag == "Bomb")
            {
                button17.Image = images[1];
                button17.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button17.Image = images[0];
                button17.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button17.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            Button button18 = (Button)sender;

            if (button18.Tag == "Bomb")
            {
                button18.Image = images[1];
                button18.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button18.Image = images[0];
                button18.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button18.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Button button19 = (Button)sender;

            if (button19.Tag == "Bomb")
            {
                button19.Image = images[1];
                button19.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button19.Image = images[0];
                button19.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button19.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            Button button20 = (Button)sender;

            if (button20.Tag == "Bomb")
            {
                button20.Image = images[1];
                button20.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button20.Image = images[0];
                button20.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button20.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            Button button21 = (Button)sender;

            if (button21.Tag == "Bomb")
            {
                button21.Image = images[1];
                button21.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button21.Image = images[0];
                button21.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button21.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            Button button22 = (Button)sender;

            if (button22.Tag == "Bomb")
            {
                button22.Image = images[1];
                button22.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button22.Image = images[0];
                button22.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button22.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            Button button23 = (Button)sender;

            if (button23.Tag == "Bomb")
            {
                button23.Image = images[1];
                button23.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button23.Image = images[0];
                button23.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button23.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            Button button24 = (Button)sender;

            if (button24.Tag == "Bomb")
            {
                button24.Image = images[1];
                button24.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button24.Image = images[0];
                button24.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button24.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            Button button25 = (Button)sender;

            if (button25.Tag == "Bomb")
            {
                button25.Image = images[1];
                button25.BackgroundImageLayout = ImageLayout.Zoom;
            }
            else
            {
                button25.Image = images[0];
                button25.BackgroundImageLayout = ImageLayout.Zoom;
            }
            countClicks++;
            if (countClicks == 1)
            {
                if (button25.Image == images[1])
                {
                    MessageBox.Show("Вы проиграли");
                    panel1.Enabled = false;
                    button26.Visible = true;                    
                    Show();
                }
                else
                {
                    //Win();
                    countClicks = 0;
                    return;
                }
            }
            
        }


        private void ImagesLoad()
        {
            images[0] = System.Drawing.Image.FromFile("crystal.png");
            images[1] = System.Drawing.Image.FromFile("bomb.png");
        }

        private void BombLoad()
        {
            for (int i = 0; i < BombsCount; i++)
            {
                int index = rnd.Next(buttons.Length);
                while (buttons[index].Tag == "Bomb")
                {
                    index = rnd.Next(buttons.Length);
                }

                if (i < BombsCount)
                {
                    buttons[index].Tag = "Bomb";
                }
                else
                {
                    buttons[index].Tag = "Crystal";
                }

                bombIndexes.Add(index);
            }
        }

        private void InitButtons()
        {
            buttons[0] = button1;
            buttons[1] = button2;
            buttons[2] = button3;
            buttons[3] = button4;
            buttons[4] = button5;
            buttons[5] = button6;
            buttons[6] = button7;
            buttons[7] = button8;
            buttons[8] = button9;
            buttons[9] = button10;
            buttons[10] = button11;
            buttons[11] = button12;
            buttons[12] = button13;
            buttons[13] = button14;
            buttons[14] = button15;
            buttons[15] = button16;
            buttons[16] = button17;
            buttons[17] = button18;
            buttons[18] = button19;
            buttons[19] = button20;
            buttons[20] = button21;
            buttons[21] = button22;
            buttons[22] = button23;
            buttons[23] = button24;
            buttons[24] = button25;
        }

        private void button26_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Restart();
        }

        private void Show()
        {
            foreach (Control control in panel1.Controls)
            {
                if (control is Button button)
                {
                    if (button.Tag == "Bomb")
                    {
                        button.Image = images[1];
                    }
                    else
                    {
                        button.Image = images[0]; 
                    }
                    button.BackgroundImageLayout = ImageLayout.Zoom;
                }
            }
        }

        private void Win()
        {
            bool allCrystalsClicked = true;

            foreach (Control control in panel1.Controls)
            {
                if (control is Button button)
                {
                    if (button.Tag == "Bomb" && button.Image == images[1]) 
                    {
                        allCrystalsClicked = false; 
                        break;
                    }
                    if (button.Tag == "Crystal" && button.Image != images[0]) 
                    {
                        allCrystalsClicked = false; 
                        break;
                    }
                }
            }

            if (allCrystalsClicked)
            {
                MessageBox.Show("Поздравляем, вы выиграли!");
                button26.Visible = true; 
                panel1.Enabled = false; 
                Show();
            }
        }
    }
}
