﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace miner
{
    public partial class Form1 : Form
    {
        private Form2 form2;
        public Form1()
        {
            InitializeComponent();
            form2 = new Form2();
        }

        private void button26_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" || textBox2.Text != "")
            {
                if (!char.IsLetter(textBox1.Text[0]) || !char.IsSymbol(textBox1.Text[0]) || !char.IsPunctuation(textBox1.Text[0]) || !char.IsLetter(textBox2.Text[0]) || !char.IsSymbol(textBox2.Text[0]) || !char.IsPunctuation(textBox2.Text[0]))
                {
                    int n = Convert.ToInt32(textBox1.Text);
                    if (n <= 0 || n >= 25)
                    {
                        MessageBox.Show("Вы не можете начать игру, если вы выбрали 0 мин или 25 мин");
                        return;
                    }
                    else
                    {
                        int ns = Convert.ToInt32(textBox1.Text);
                        form2.BombsCount = ns;
                        form2.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("В полях ввода мин или баланса, не могут присутствовать символы, знаки пунктуации, или буквы");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Поля не могут быть пустыми");
                return;
            }
        }
    }
}
